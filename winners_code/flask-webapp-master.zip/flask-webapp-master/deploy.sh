docker stop flask-app

git pull origin master

docker-compose up --build -d flask-app
