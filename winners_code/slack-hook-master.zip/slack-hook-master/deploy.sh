docker stop slack-hook

git pull origin master

docker-compose up --build -d slack-hook
