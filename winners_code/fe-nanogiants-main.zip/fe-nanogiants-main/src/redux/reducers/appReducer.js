export function appReducer(state = { ready: false }, action) {
  switch (action.type) {
    case "APP_READY":
      return {
        ...state,
        "ready": true
      };

    default:
      return state;
  }
}
