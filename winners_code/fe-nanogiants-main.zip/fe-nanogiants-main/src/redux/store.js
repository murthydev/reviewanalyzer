import { createStore, applyMiddleware  } from 'redux';
import reducers from './reducers/reducer';
import thunk from 'redux-thunk';

export const middlewares = [thunk]

const store = createStore(reducers, applyMiddleware(...middlewares));

export default store