import React from 'react'
import TopNav from '../utils/TopNav'

export default function Files() {
    return (
        <div>
            <TopNav />

            File
        </div>
    )
}
