import React from 'react';
import TopNav from '../utils/TopNav';
import { Row, Button, Col, Card } from 'react-bootstrap';
import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <>
      <TopNav />
      <Row>
        <Col>
          <h1 class="text-center">Get a better idea of what your customer values about you</h1>
        </Col>
      </Row>
      <Row>
        <Row className="justify-content-center mt-5">
          <div className='col-3 m-2'>
            <Link to="/file">
              <Card bg="primary" text="white" style={{ width: '30rem' }} >
                <Card.Header>Upload Files</Card.Header>
                <Card.Body>
                  <Card.Title>Here you can add new Files</Card.Title>
                  <Card.Text>Adding new files will put them into a job que and they will included in the next iteration for the ML model creation</Card.Text>
                </Card.Body>
              </Card>
            </Link>
          </div>
          <div className='col-3 m-2'>
            <Link to="/">
              <Card bg="primary" text="white" style={{ width: '30rem' }} >
                <Card.Header>Access Data</Card.Header>
                <Card.Body>
                  <Card.Title>Query the database</Card.Title>
                  <Card.Text>Here you can query the database and get the statistical results from the NLP algorithm to analyse the data. </Card.Text>
                </Card.Body>
              </Card>
            </Link>
          </div>
        </Row>
      </Row>
    </>
  );
}
