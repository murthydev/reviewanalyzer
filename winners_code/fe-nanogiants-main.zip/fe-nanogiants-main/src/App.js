import { Row, Button, Col, Navbar, Container, Nav, NavDropdown} from 'react-bootstrap';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './components/pages/Home';
import Files from './components/pages/Files';


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="/files" element={<Files/>} />
        {/* <Route path="/files" element={<Files/>} /> */}
      </Routes>
    </Router>
  );
}

export default App;
