docker stop nlp-preprocessing

git pull origin master

docker-compose up --build -d nlp-preprocessing
